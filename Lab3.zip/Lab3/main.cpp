#include "trip.h"
#include <iostream>
#include <string>
#include <vector>
#include <sstream>

string fvectorToString(const vector<float>& v) {
    ostringstream oss;

    for (const auto& s : v) {
        oss << s << " ";
    }

    string newString = oss.str();
    if (!newString.empty()) {
        newString.pop_back();
    }
    return newString;
}


int main() {
    vector<float> dues1 = {10.00, 20.00, 30.00};
    vector<float> cdues1(dues1);
    float outCome1 = moneyEqualizer(cdues1);
    vector<float> dues2 = {15.00, 15.01, 3.00, 3.01};
    vector<float> cdues2(dues2);
    float outCome2 = moneyEqualizer(cdues2);
    vector<float> dues3 = {40.00, 3.00, 7.57, 9.00};
    vector<float> cdues3(dues3);
    float outCome3 = moneyEqualizer(cdues3);

    cout << fvectorToString(cdues1) << endl;
    cout << outCome1 << endl;
    cout << fvectorToString(cdues2) << endl;
    cout << outCome2 << endl;
    cout << fvectorToString(cdues3) << endl;
    cout << outCome3 << endl;
    return 0;
}