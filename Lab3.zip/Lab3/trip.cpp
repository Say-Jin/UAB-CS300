#include "trip.h"
#include <iostream>
#include <string>
#include <numeric>
#include <cmath>

float moneyEqualizer(vector<float> expenses) {
    float tripCost = accumulate(expenses.begin(), expenses.end(), 0.0);
    int people = expenses.size();
    float avgCost = tripCost / people;
    float evenDues = 0.0;

    for (const auto& expense : expenses) {
        float splits = expense - avgCost;
        if (splits < 0) {
            evenDues += fabs(splits);
        }
    }
    return round(evenDues * 100.0) / 100.0;
}