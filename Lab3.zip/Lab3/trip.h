#ifndef _trip_h
#define _trip_h

#include <iostream>
#include <string>
#include <vector>

using namespace std;

float moneyEqualizer (vector<float> expenses);

#endif